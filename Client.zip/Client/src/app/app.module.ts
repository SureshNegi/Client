import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { routes } from './app.routing';
import { AppComponent } from './app.component';
import { HomeComponent } from './views/clientlist/clientlist.component';
import { HeaderComponent } from './views/header/header.component';
import { ClientFilterPipe } from './pipes/client/filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    ClientFilterPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    routes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
