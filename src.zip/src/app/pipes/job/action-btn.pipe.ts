import { Pipe, PipeTransform } from '@angular/core';
import { Job, JobStatusEnum } from '../../models/job';
@Pipe({ name: 'actionBtn' })
export class JobActionBtnPipe implements PipeTransform {
    transform(obj: Job, btnType: number): boolean {
        let result: boolean = false;
        switch (btnType) {
            case 1:
                result = this.isEditBottonEnable(obj);
                break;
            case 2:
                result = this.isCopyBottonEnable(obj);
                break;
            case 3:
                result = this.isCopyBottonEnable(obj);
                break;
            case 4:
                result = this.isRunNowBottonEnable(obj);
                break;
            case 5:
                result = this.isRestartBottonEnable(obj);
                break;
            case 6:
                result = this.isResumeBottonEnable(obj);
                break;
            case 7:
                result = this.isDeleteBottonEnable(obj);
                break;
        }
        return result;

    }

    private isEditBottonEnable(obj: Job): boolean {
        return (
            //(obj.JobStatusId == JobStatusEnum.Running)
            (obj.JobStatusId == JobStatusEnum.Completed)
            || (obj.JobStatusId == JobStatusEnum.Error)
        );
    }
    private isCopyBottonEnable(obj: Job): boolean {
        return true;
    }
    private isRunNowBottonEnable(obj: Job): boolean {
        return (

            (obj.JobStatusId == JobStatusEnum.Completed)
        );

    }
    private isRestartBottonEnable(obj: Job): boolean {
        return (

            (obj.JobStatusId == JobStatusEnum.Error)
        );
    }
    private isResumeBottonEnable(obj: Job): boolean {
        return (

            (obj.JobStatusId == JobStatusEnum.Error)
        );
    }
    private isDeleteBottonEnable(obj: Job): boolean {
        return (
            (obj.JobStatusId == JobStatusEnum.Completed)
            || (obj.JobStatusId == JobStatusEnum.Error)
        );
    }
}


