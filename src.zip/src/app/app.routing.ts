import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule }   from '@angular/router';
import { AppComponent } from './app.component';

const appRoutes: Routes = [
/** 
  { path: '', pathMatch: 'full', component: LoginComponent },
  { path: 'home', component: HomeComponent }, 
  { path: '**', redirectTo: 'not-found' }*/
];
/**
 *   { path: '', pathMatch: 'full', component: LoginComponent },
 */
export const routes: ModuleWithProviders = RouterModule.forRoot(appRoutes);


