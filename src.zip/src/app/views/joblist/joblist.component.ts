import { Component, OnInit } from '@angular/core';
import { Job } from '../../models/job';
import { JobService } from '../../services/job.service';


@Component({
  selector: 'app-joblist',
  templateUrl: './joblist.component.html',
  styleUrls: ['./joblist.component.css']
})
export class JoblistComponent implements OnInit {
  constructor(private jobService: JobService) { }
  jobs: Job[];
  ngOnInit() {
    this.getJobs();
  }
  getJobs(): void {
    this.jobService.getJobs()
      .subscribe(data => {
        setTimeout(() => {
          //this.isLoading = false;
          this.jobs = data;  }, 3000);
      });
  }

  updateActionButtonFlags(jobs:Job[]){
    

  }


}
