import { Component, OnInit } from '@angular/core';
import { Client } from '../../models/client';
import { ClientService } from '../../services/client.service';


@Component({
  selector: 'app-clientlist',
  templateUrl: './clientlist.component.html',
  styleUrls: ['./clientlist.component.css']
})
export class HomeComponent implements OnInit {


  clients: Client[];
  isLoading: boolean;

  constructor(
    private clientService: ClientService) { }

  ngOnInit() {
    this.isLoading = true;
    this.getClient();
  }

  getClient(): void {
    this.clientService.getClients()
      .subscribe(data => {
        setTimeout(() => {
          this.isLoading = false;
          this.clients = data;  }, 3000);
      });
  }

}
