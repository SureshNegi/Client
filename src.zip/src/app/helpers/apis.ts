// Api URL
const apiURL = '/';


// Api methods

export const getClients = apiURL + '/';
