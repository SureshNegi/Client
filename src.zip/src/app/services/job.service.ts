
import { Injectable } from '@angular/core';
import { Job } from '../models/job';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { catchError, map, tap } from 'rxjs/operators';
import * as APIs from '../helpers/apis';

@Injectable({
  providedIn: 'root'
})
export class JobService {
  constructor() { }
  jobs: Job[];
  getJobs(): Observable<Job[]> {

    this.jobs = [
      { JobId: 1, JobName: 'OG_BCBS',JobDescription:'OG BCBS',JobFrequency:'Weeklly',JobInterval:'5 am-10am ET'
      ,JobCurrentStatus:'Running',JobStatusId:1},
      { JobId: 2, JobName: 'OG_BCBS',JobDescription:'OG BCBS',JobFrequency:'Weeklly',JobInterval:'5 am-10am ET'
      ,JobCurrentStatus:'completed',JobStatusId:2 },
      { JobId: 3, JobName: 'OE_AETNA',JobDescription:'OG BCBS',JobFrequency:'Weeklly',JobInterval:'5 am-10am ET'
      ,JobCurrentStatus:'Error',JobStatusId:3 },
      { JobId: 4, JobName: 'OG_AETNA',JobDescription:'OG BCBS',JobFrequency:'Weeklly',JobInterval:'5 am-10am ET'
      ,JobCurrentStatus:'Running',JobStatusId:1 },


    ]

        // return this.http.get<Client[]>('URL')
      return of(this.jobs);
  }
}
