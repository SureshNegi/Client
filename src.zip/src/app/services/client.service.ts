import { Injectable } from '@angular/core';
import { Client } from '../models/client';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { catchError, map, tap } from 'rxjs/operators';
import * as APIs from '../helpers/apis';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  clients: Client[];

  constructor() { }

  getClients(): Observable<Client[]> {

    this.clients = [
      { ClientId: '1', ClientName: 'Client 1', ClientOneCode: 'ClientOneCode1' },
      { ClientId: '2', ClientName: 'Client 2', ClientOneCode: 'ClientOneCode2' },
      { ClientId: '3', ClientName: 'Client 3', ClientOneCode: 'ClientOneCode3' },
      { ClientId: '4', ClientName: 'Client 4', ClientOneCode: 'ClientOneCode4' },
      { ClientId: '5', ClientName: 'Client 5', ClientOneCode: 'ClientOneCode5' }];

        // return this.http.get<Client[]>('URL')
      return of(this.clients);
  }
}
