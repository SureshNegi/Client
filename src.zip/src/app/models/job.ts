export class Job {
    JobId:number;
    JobName: string;
    JobDescription: string;
    JobFrequency: string;
    JobInterval:string;
    JobStatusId:number;
    JobCurrentStatus:string;   
}

export enum JobStatusEnum{
    Running=1,
    Completed=2,
    Error=3,
}