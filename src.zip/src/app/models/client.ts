export class Client {
    ClientId: string;
    ClientName: string;
    ClientOneCode: string;
}
